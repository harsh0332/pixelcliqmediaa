# Pixelcliq Media — logo motion spec

Mark direction: **The Return** — one unbroken monoline stroke that travels 270° around a
16-unit circle, then turns inward on an 8-unit arc and stops at the centre.

    viewBox   0 0 48 48
    path      M8 24A16 16 0 1 1 24 40A8 8 0 0 1 24 24
    stroke    3 units (= 1.5px at 24px, 15px at 240px)
    caps      butt, joins miter (default — no rounding)
    length    100.53 units  (0.75·2π·16 = 75.40) + (π·8 = 25.13)

## Palette

| token  | value     | use                          |
|--------|-----------|------------------------------|
| ink    | `#14151A` | mark, wordmark, inverse bg   |
| bone   | `#F7F5F0` | background, inverse stroke   |
| accent | `#2C4BFF` | hover state, footer sweep    |
| line   | `#E2DDD3` | hairlines                    |

Wordmark: Clash Display 600 (Fontshare), `letter-spacing: -0.02em`, ink.
Fallbacks: General Sans 600 → system sans.

Master easing for every animation: `cubic-bezier(0.22, 1, 0.36, 1)`.
Framer Motion equivalent: `ease: [0.22, 1, 0.36, 1]`.

---

## Variant 1 — Header entrance

**Trigger:** page load. Plays exactly once. No loop, no repeat, no replay on
route change. Total wall time **900ms**.

| # | Element | Property | From → To | Duration | Delay | Easing |
|---|---------|----------|-----------|----------|-------|--------|
| 1 | mark `path` | `stroke-dashoffset` (dasharray `100.53`) | `100.53` → `0` | 560ms | 0ms | `cubic-bezier(0.22,1,0.36,1)` |
| 2 | each wordmark letter | `opacity` | `0` → `1` | 180ms | `380 + i·26` ms | same |
| 3 | each wordmark letter | `transform: translateY` | `6px` → `0` | 180ms | `380 + i·26` ms | same |

- Stagger: **26ms**, index `i` = 0…14 over `Pixelcliq Media` (the space counts as an
  index so the two words stay in rhythm). Last letter starts at 744ms, ends at 924ms —
  clamp to 900ms by using 24ms stagger if the exact budget matters.
- Fill mode `forwards` on both; no `animation-direction: alternate`, no `iteration-count`
  above 1.
- Deliberately no overshoot, no spring, no scale. If you reimplement with a spring, the
  motion is wrong.

Framer Motion sketch:

    // container
    transition: { staggerChildren: 0.026, delayChildren: 0.38 }
    // mark
    initial={{ pathLength: 0 }} animate={{ pathLength: 1 }}
    transition={{ duration: 0.56, ease: [0.22,1,0.36,1] }}
    // letter
    initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.18, ease: [0.22,1,0.36,1] }}

**Reduced motion:** no animation runs. Mark renders with `stroke-dashoffset: 0`, letters
at `opacity: 1` and `transform: none`, on the first paint.

---

## Variant 2 — Hover

**Trigger:** `:hover` and `:focus-visible` on the lockup link. Mark only — the wordmark
never moves or changes colour. Transition, not keyframes, so it reverses cleanly.

| Element | Property | Rest → Hover | Duration | Delay | Easing |
|---------|----------|--------------|----------|-------|--------|
| `svg.pc-hover` | `color` (mark stroke is `currentColor`) | `#14151A` → `#2C4BFF` | 200ms | 0 | `cubic-bezier(0.22,1,0.36,1)` |
| `svg.pc-hover` | `stroke-dashoffset` (inherited by the path; dasharray `100.53`) | `7` → `0` | 200ms | 0 | same |

At rest the inward return stops 7 units short of the centre — the form is open. On hover
it completes: the loop closes and turns accent. Mouse-out plays the same transition in
reverse at the same 200ms.

Note: `stroke-dasharray` / `stroke-dashoffset` are inherited SVG properties, so they are
set once on the `<svg>` and must **not** be re-declared as attributes on the `<path>`
(a presentation attribute would beat the inherited value).

Framer Motion sketch:

    whileHover={{ stroke: '#2C4BFF', strokeDashoffset: 0 }}
    initial={{ stroke: '#14151A', strokeDashoffset: 7 }}
    transition={{ duration: 0.2, ease: [0.22,1,0.36,1] }}

**Reduced motion:** `transition: none`; the mark renders closed (`stroke-dashoffset: 0`)
at rest and only the colour changes on hover, instantly.

---

## Variant 3 — Footer wordmark

**Trigger:** scroll into view, `IntersectionObserver` at `threshold: 0.4`, `unobserve`
immediately after firing so it can never replay. No JS beyond that (16 lines,
vanilla, with a no-IntersectionObserver fallback that renders the end state).

Geometry: SVG `viewBox="0 0 1600 300"`, wordmark at `font-size: 180`,
`textLength="1560" lengthAdjust="spacing"` so the letters are stretched to fill the full
measure (this is the "enormous, letter-spaced" setting — the tracking is a product of the
fit, not a fixed em value). A 2px `#E2DDD3` hairline sits at `y = 262`.

Layering: ink `<text>` on the bottom; an identical accent `<text>` above it inside
`<g clip-path="url(#fw-clip)">`; the clip is a single `<rect>`.

| Element | Property | From → To | Duration | Delay | Easing |
|---------|----------|-----------|----------|-------|--------|
| `rect.pc-footer-clip` | `transform: translateX` | `-1600px` → `0` | 1200ms | 0ms | `cubic-bezier(0.22,1,0.36,1)` |

The accent fill therefore appears to sweep left → right across the letters once, then
holds (`forwards`). Nothing else animates — no letter stagger, no opacity.

Framer Motion sketch: animate the clip rect's `x` or `translateX` from `-1600` to `0`
with `whileInView` + `viewport={{ once: true, amount: 0.4 }}`,
`transition={{ duration: 1.2, ease: [0.22,1,0.36,1] }}`.

**Reduced motion:** the clip rect renders at `translateX(0)` — the wordmark is fully
accent-filled on first paint, no sweep.

---

## Accessibility

- Standalone marks (`mark*.svg`, lockups) carry `role="img"` + `<title>` referenced by
  `aria-labelledby`.
- Beside live text (header lockup, hover lockup) the SVG is `aria-hidden="true"` and the
  accessible name comes from the text or the link's `aria-label`.
- The entrance letter spans are wrapped in one element with
  `aria-label="Pixelcliq Media"` so screen readers get the word, not 15 characters.
- Hover state also fires on `:focus-visible` for keyboard users.

## Files

    mark.svg               ink on transparent
    mark-accent.svg        accent on transparent
    mark-inverse.svg       bone on ink (48×48 ink plate included)
    wordmark.svg           Clash Display 600, -0.02em
    lockup-horizontal.svg  mark 64px + 20px gap + wordmark 62px
    lockup-stacked.svg     mark 72px centred above wordmark 54px
    logo-entrance.html     variant 1 demo (has a Replay button; production never replays)
    logo-hover.html        variant 2 demo
    footer-wordmark.html   variant 3 demo (scroll down)
    animation.css          all keyframes + transitions + reduced-motion guards

The `.svg` files reference the Clash Display webfont by name for the wordmark. Convert the
text to outlines before shipping them anywhere the font isn't loaded (email, third-party
sites, print).
