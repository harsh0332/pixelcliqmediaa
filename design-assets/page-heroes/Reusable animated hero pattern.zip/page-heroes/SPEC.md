# Page Hero — inner-page hero pattern

One component, five variants. Light, editorial, hairline-driven. Deliberately quieter than
the homepage hero: it carries a page, it does not carry the brand.

```
/page-heroes
  page-hero.css        base pattern + per-variant overrides (sections 1–10)
  page-hero.js         6 KB, no dependencies
  hero-services.html   variant: services
  hero-pillar.html     variant: pillar   (one template, six pillars)
  hero-work.html       variant: work
  hero-about.html      variant: about
  hero-contact.html    variant: contact
  SPEC.md
```

---

## 1. Build once vs. build as a prop

### Shared — build ONCE (`PageHero` base)

| Piece | Element | Notes |
|---|---|---|
| Section shell | `.page-hero` | bone background, `clamp()` padding, vertically centred |
| Grid | `.page-hero__inner` | 1 col; 2 cols ≥1080px only when `data-accent="side"` |
| Eyebrow | `.hero-eyebrow` | 0.75rem / Satoshi 500 / uppercase / 0.12em |
| Headline | `.hero-h1` + `.hero-h1__line > span` | masked line reveal; one real `<h1>` |
| Support | `.hero-support` | `max-width: 62ch` |
| CTA row | `.hero-cta` | optional; flex + `gap` |
| Hairline | `.hero-rule` | `scaleX` draw, last child of `.hero-body` |
| Accent slot | `.hero-accent` | sibling of `.hero-body`; empty on `about` |
| Motion chain | `.is-in` + `@keyframes hero*` | one class toggle drives all of it |
| Runtime | `page-hero.js` | releases `is-in`, assigns `--i`, reduced-motion guard |

### Variant-specific — build as props

```ts
type PageHeroProps = {
  variant: 'services' | 'pillar' | 'work' | 'about' | 'contact';
  eyebrow: string;                 // 'SERVICES' | 'WORK' | …
  headlineLines: string[];         // one entry per masked line (line breaks are authored)
  support: string;
  ctas?: { label: string; href: string; quiet?: boolean }[];
  accentPosition: 'side' | 'below' | 'none';

  // variant: pillar
  pillar?: { n: string; name: string; support: string; capabilities: string[] };
  // variant: about
  emphasise?: string[];            // words in the headline that receive accent underlines
  // variant: contact
  steps?: { title: string; copy: string }[];
};
```

Contracts:

- `variant` sets a `data-variant` attribute; **all** variant CSS is scoped by the accent
  block's own class, so a variant you don't render costs nothing.
- `accentPosition` maps to `data-accent`. `side` is the only value that turns on the 2-column
  grid. `below` and `none` stay single-column at every width.
- The headline is authored as explicit lines. Line breaks are a design decision, not a
  measurement — pass `headlineLines`, don't split at runtime.
- `pillar` is the only variant with a data payload (`PILLARS` in `page-hero.js`, six entries).
  Swap it for the CMS record; nothing else changes.

---

## 2. Motion — shared chain (identical on all five)

Custom properties in `:root`, so a developer retimes the family in one place.

| Step | Element | Delay | Duration | Transform | Easing |
|---|---|---|---|---|---|
| 1 | eyebrow | `0.05s` | 600ms | `translateY(16px) → 0` + opacity | `cubic-bezier(.22,1,.36,1)` |
| 2 | H1 lines | `0.15s` + `0.06s × index` | 700ms | `translateY(120%) → 0` inside `overflow:hidden` | same |
| 3 | support | `0.4s` | 600ms | `translateY(16px) → 0` + opacity | same |
| 4 | CTA row | `0.48s` | 600ms | `translateY(16px) → 0` + opacity | same |
| 5 | hairline | `0.5s` | 600ms | `scaleX(0) → 1`, origin left | same |
| 6 | accent | `0.55s` | per variant | per variant | same |

`--ease: cubic-bezier(0.22, 1, 0.36, 1)` everywhere. Nothing loops; `animation-fill-mode: both`
holds the final state. The CTA step (4) is the one timing not in the original brief — it is
inserted between support and hairline so the text block resolves top-to-bottom.

## 3. Motion — per variant (step 6)

**SERVICES** — hairline loop diagram, seven nodes on a 118px-radius ring.
Group fades in at `0.55s` / 600ms. The accent path (`.trace`, 1.25px `--accent`) traces once
from the 01 node clockwise at `0.6s` over **1000ms** via `stroke-dashoffset: 742 → 0`, then
stays drawn. *Only exception to transform/opacity-only: a stroke trace has no transform
equivalent. `stroke-dashoffset` is paint-only — it does not affect layout.*

**PILLAR** — right-rail capability index.
Spine `scaleY(0) → 1` at `0.55s` / 700ms. Then per row, `0.55s + 0.08s + 0.05s × index`:
row text rises 10px (520ms) while its bottom hairline draws `scaleX(0) → 1` (520ms).
Five rows → last row starts at `0.83s`.

**WORK** — three placeholder frames, native ad ratios.
`0.55s + 0.09s × index`, 720ms: `translateY(20px) rotate(±2°) → translateY(0) rotate(0)`
plus opacity. Per-frame rotations `-2°, 1.4°, -1.2°`; all settle at 0. Explicit pixel
dimensions per breakpoint (never a percentage), so there is no reflow. `box-sizing:
border-box` keeps the 1px hairline inside the ratio, and each set is sized to fit the rail
it sits in (row = frames + 2×14px gap):

| Breakpoint | 9:16 | 4:5 | Row | Rail |
|---|---|---|---|---|
| ≥1360px | 102×181 | 128×160 | 360px | ≥367px |
| ≥1080px | 96×171 | 120×150 | 312px | ≥340px (floor) |
| 421–1079px | 99×176 | 132×165 | 358px | full width |
| ≤420px | 84×149 | 112×140 | 308px | full width |

The side rail floor is `clamp(340px, 27vw, 372px)` — raised from 280px specifically so the
frame row never overflows or clips at the low end of the two-column range. The caption fades
in at `0.9s`.

**ABOUT** — no accent block. The four nouns in the headline (`creative`, `funnel`,
`technology`, `numbers`) carry a 2px accent underline on `::after`, `scaleX(0) → 1`, 520ms,
starting at **`1.05s + 0.15s × index`** — i.e. after the headline settles
(`0.15s + 2×0.06s + 0.7s ≈ 0.97s`). Last underline finishes ≈ `2.0s`. Restraint is the design.

**CONTACT** — three-step "what happens next".
Each step rises 16px at `0.55s + 0.08s × index`. Each number marker then fills:
an accent disc `scale(0) → 1` (420ms) at `0.7s + 0.2s × index`, with the numeral
cross-fading muted → paper (260ms) at `0.78s + 0.2s × index`. The fill is two stacked
numerals, not an animated `color`, so it stays opacity-only; the paper copy is
`aria-hidden`.

---

## 4. Accessibility

- **One real `<h1>` per hero.** Masked lines are `<span>` wrappers inside it — the text run
  stays contiguous and whitespace between line spans is preserved, so the accessible name is
  exactly the sentence. Nothing is duplicated, hidden, or `aria-label`-replaced.
- The services diagram is `role="img"` with an `aria-label`; its numeric labels are decorative.
- Work frames are `aria-hidden` (they are placeholders, not content).
- Contact's `n--fill` numeral is `aria-hidden` so "01" is announced once.
- `prefers-reduced-motion: reduce` kills every animation and transition inside `.page-hero`
  and renders the final state instantly: `opacity: 1`, `transform: none`,
  `stroke-dashoffset: 0`, filled markers. No JS runs the sequence — `page-hero.js` checks the
  query first and returns before touching `is-in`.
- No-JS: initial hidden states are gated on `html.js` (set by a one-line inline script in
  `<head>`). Without JS the hero renders fully visible and static.

---

## 5. Implementation notes

- **`--i` is set by JS**, not `nth-child`, so a variable-length list (pillar capabilities,
  contact steps) needs no CSS edits. Any container marked `data-stagger` gets its direct
  children indexed; elements marked `data-stagger-self` are indexed as a flat set
  (used by the about underlines, which are not siblings). Masked H1 lines are indexed
  unconditionally (`:scope > .hero-h1__line`), so the headline stagger needs no markup hook
  and stays independent of the about underline index.
- **The reveal must not depend on `requestAnimationFrame` alone.** rAF is throttled or never
  fires in hidden/offscreen frames, which would leave the hero stuck in its initial (invisible)
  state. `nextTick()` races rAF against a 32ms timeout — whichever lands first adds `is-in`.
- **The sequence is released on visibility, with a guaranteed fallback.** Three triggers race
  and the first one wins (then the observer disconnects and the listener is removed, so it
  still fires exactly once):
  1. `IntersectionObserver`, threshold 0.15 — the intended path; matters when the hero sits
     below the fold or in a render-throttled iframe, where a load-time release would run the
     animation clock-less and the user would land on a finished state.
  2. `visibilitychange` → visible, registered only if the document starts hidden.
  3. `setTimeout(release, 1200)` — a hard deadline.

  **The deadline is not optional.** Because the initial state is `opacity: 0` /
  `translateY(120%)`, an IO-only trigger would hide the H1 permanently in any hidden,
  prerendered or notification-starved document. Firing early is cosmetic; never firing is a
  content bug.
- **Fonts**: `document.fonts.ready` gates the reveal, capped at 600ms, so masked lines never
  reveal on fallback metrics and never hang if the CDN is slow.
- **Replay**: `PageHero.play(el)` / `PageHero.playAll()` re-fire a hero (used by the pillar
  demo switcher). No-ops under reduced motion.
- **Mask clipping**: `.hero-h1__line` uses `padding: .1em 0 .16em` with a matching negative
  margin so ascenders and descenders are not cut by `overflow: hidden`.
  Lines containing the Instrument Serif italic `<em>` get a deeper bottom pad.
- `will-change: transform` is set only on the two elements that need it (H1 line inners,
  work frames).
- The demo bar in `hero-pillar.html` (`.demo-bar`, section 9 of the CSS) is **not part of
  the component** — delete it and CSS section 9 on integration.

## 6. Breakpoints checked

`1440px` (2-column, side accent), `768px` (single column, accent below the rule),
`390px` (single column, small frame set, H1 at the 2.25rem floor).
