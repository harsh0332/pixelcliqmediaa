/* =============================================================================
   page-hero.js — minimal runtime for the inner-page hero pattern.

   Responsibilities (all shared, build once):
     1. release the initial hidden states once fonts have settled (`is-in`)
     2. hand every staggered group its `--i` index
     3. skip the sequence entirely under prefers-reduced-motion
     4. bind the PILLAR variant's data (variant-specific data, shared binder)
     5. expose PageHero.play() / PageHero.playAll() for replay

   No dependencies. No loops. Each hero fires once per page load.
   ============================================================================= */
(function () {
  "use strict";

  var REDUCED = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* --- PILLAR data ------------------------------------------------------- */
  var PILLARS = [
    {
      n: "01",
      name: "Creative Strategy",
      support: "The offer, the angle and the format are decided before anything gets made.",
      capabilities: ["Offer & angle mapping", "Concept sprints", "Script & storyboard", "Static systems", "Creative QA"]
    },
    {
      n: "02",
      name: "Paid Social",
      support: "Account structure that lets creative do the heavy lifting, and reads that hold up.",
      capabilities: ["Account architecture", "Testing cadence", "Budget shaping", "Creative rotation", "Incrementality reads"]
    },
    {
      n: "03",
      name: "Search & Shopping",
      support: "Demand capture kept honest — clean feeds, clear splits, nothing hiding in blended.",
      capabilities: ["Feed hygiene", "Query mining", "Brand / non-brand split", "PMax containment", "Bid governance"]
    },
    {
      n: "04",
      name: "Retention & CRM",
      support: "Owned channels built as a system of flows, not a calendar of sends.",
      capabilities: ["Lifecycle mapping", "Flow builds", "Segment logic", "SMS cadence", "Deliverability"]
    },
    {
      n: "05",
      name: "Conversion & Site",
      support: "Fewer, better tests on the pages where the money actually changes hands.",
      capabilities: ["Landing page systems", "PDP testing", "Checkout friction", "Speed budgets", "Test backlog"]
    },
    {
      n: "06",
      name: "Measurement",
      support: "One number everyone trusts, and the plumbing underneath to defend it.",
      capabilities: ["Server-side tagging", "Attribution model", "MER framework", "Incrementality tests", "Reporting layer"]
    }
  ];

  /* --- helpers ---------------------------------------------------------- */

  function each(list, fn) { Array.prototype.forEach.call(list, fn); }

  // Every element that participates in a stagger reads `--i` from its own style.
  function indexStaggers(hero) {
    // masked H1 lines always stagger — no attribute needed on the markup
    each(hero.querySelectorAll(".hero-h1"), function (h1) {
      each(h1.querySelectorAll(":scope > .hero-h1__line"), function (el, i) {
        el.style.setProperty("--i", i);
      });
    });
    each(hero.querySelectorAll("[data-stagger]"), function (group) {
      each(group.children, function (el, i) { el.style.setProperty("--i", i); });
    });
    each(hero.querySelectorAll("[data-stagger-self]"), function (el, i) {
      el.style.setProperty("--i", i);
    });
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }

  /* --- PILLAR binder ---------------------------------------------------- */

  function renderPillar(hero, index) {
    var p = PILLARS[index] || PILLARS[0];
    hero.setAttribute("data-pillar", p.n);

    hero.querySelector("[data-pillar-num]").textContent = p.n;
    hero.querySelector("[data-pillar-support]").textContent = p.support;

    // H1 is rebuilt as a single masked line so the accessible name stays intact.
    hero.querySelector("[data-pillar-name]").innerHTML =
      '<span class="hero-h1__line" style="--i:0"><span>' + escapeHtml(p.name) + "</span></span>";

    hero.querySelector("[data-pillar-caps]").innerHTML = p.capabilities.map(function (c, i) {
      var n = ("0" + (i + 1)).slice(-2);
      return '<li class="hero-index__item"><span>' +
        '<span class="hero-index__n">' + n + "</span>" +
        '<span class="hero-index__name">' + escapeHtml(c) + "</span>" +
        "</span></li>";
    }).join("");

    indexStaggers(hero);
  }

  function bindPillar(hero) {
    var param = parseInt(new URLSearchParams(location.search).get("pillar"), 10);
    var start = isNaN(param) ? 1 : Math.min(Math.max(param, 1), PILLARS.length);
    renderPillar(hero, start - 1);

    var bar = document.querySelector("[data-pillar-switch]");
    if (!bar) return;
    each(bar.querySelectorAll("button"), function (btn, i) {
      btn.setAttribute("aria-pressed", String(i === start - 1));
      btn.addEventListener("click", function () {
        each(bar.querySelectorAll("button"), function (b) { b.setAttribute("aria-pressed", "false"); });
        btn.setAttribute("aria-pressed", "true");
        renderPillar(hero, i);
        if (!REDUCED) play(hero);
      });
    });
  }

  /* --- play ------------------------------------------------------------- */

  // rAF is throttled (or never fires) in hidden/offscreen frames, so it can only
  // ever be an optimisation here — a timeout always closes the sequence out.
  function nextTick(fn) {
    var ran = false;
    function once() { if (!ran) { ran = true; fn(); } }
    requestAnimationFrame(once);
    setTimeout(once, 32);
  }

  function play(hero) {
    if (REDUCED) return;
    hero.classList.remove("is-in");
    void hero.offsetWidth;                       // force a style flush so it restarts
    nextTick(function () { hero.classList.add("is-in"); });
  }

  function playAll() { each(document.querySelectorAll(".page-hero"), play); }

  // A hero placed below the fold (or inside a render-throttled frame) has no running
  // animation clock, so releasing on load would burn the sequence unseen. Start it the
  // first time the hero is actually in view; above-the-fold heroes fire immediately.
  // The observer is an optimisation, never the only path: in a hidden, prerendered or
  // notification-starved document IO callbacks may never arrive, and a hero gated to
  // opacity:0 would then hide its own H1 forever. A deadline always closes it out.
  function releaseWhenVisible(hero) {
    var done = false;
    var io = null;
    function release() {
      if (done) return;
      done = true;
      if (io) io.disconnect();
      document.removeEventListener("visibilitychange", onVisible);
      void hero.offsetWidth;                     // flush initial states, then release
      nextTick(function () { hero.classList.add("is-in"); });
    }
    function onVisible() { if (document.visibilityState === "visible") release(); }

    if ("IntersectionObserver" in window) {
      io = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) { if (e.isIntersecting) release(); });
      }, { threshold: 0.15 });
      io.observe(hero);
      if (document.visibilityState === "hidden") {
        document.addEventListener("visibilitychange", onVisible);
      }
      setTimeout(release, 1200);                 // hard deadline — first trigger wins
    } else {
      release();
    }
  }

  function init() {
    each(document.querySelectorAll(".page-hero"), function (hero) {
      indexStaggers(hero);
      if (hero.getAttribute("data-variant") === "pillar") bindPillar(hero);
      if (REDUCED) return;                       // final state is already rendered by CSS
      releaseWhenVisible(hero);
    });
  }

  // Wait for webfonts so the masked lines don't reveal on fallback metrics,
  // but never wait longer than 600ms.
  function boot() {
    var done = false;
    function go() { if (!done) { done = true; init(); } }
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(go);
      setTimeout(go, 600);
    } else {
      go();
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }

  window.PageHero = { play: play, playAll: playAll, pillars: PILLARS, reduced: REDUCED };
})();
