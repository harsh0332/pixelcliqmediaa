# Micro-interaction spec — premium editorial agency

Single source of truth for timings. Demo page: `kit.dc.html` (each interaction isolated, timings printed beside it).

## Tokens

| Token | Value |
| --- | --- |
| `--ink` | `#14151A` |
| `--ink-muted` | `#6B6C73` |
| `--bone` | `#F7F5F0` |
| `--paper` | `#FFFFFF` |
| `--line` | `#E2DDD3` |
| `--accent` | `#2C4BFF` |
| Display | Clash Display 600 |
| Body | Satoshi 400 / 500 |
| Durations | 150 / 200 / 250 / 300 / 400 / 500 / 600 / 800 ms |
| `--ease-expo` | `cubic-bezier(0.22, 1, 0.36, 1)` — entrances, translations |
| `--ease-inout` | `cubic-bezier(0.65, 0, 0.35, 1)` — state changes, colour |

## Table

| # | Interaction | Property | Duration | Easing | Trigger | Reduced motion |
| --- | --- | --- | --- | --- | --- | --- |
| 01 | Primary button — arrow lead | `transform: translateX(0 → 4px)` | 300ms | ease-expo | hover · focus-visible | snaps to 4px, no tween |
| 01 | Primary button — magnetic pull | `transform: translate3d()`, max 8px | spring `k 0.18 / damp 0.72`, rAF | — | pointermove within 56px of the box, fine pointers only | disabled entirely (no translate) |
| 01 | Primary button — active | `transform: scale(0.97)` | 150ms | ease-inout | pointerdown | instant |
| 01 | Primary button — loading | spinner `rotate(360deg)` replaces arrow; label persists; `aria-busy="true"` | 800ms/turn | linear | click | animation kept (status indicator), everything else instant |
| 01 | Primary button — disabled | `background #C9D0F5`, `cursor: not-allowed`, no motion | — | — | `[disabled]` | n/a |
| 02 | Secondary button — inversion fill | `background-color`, `color` | 300ms | ease-inout | hover · focus-visible | applies instantly |
| 03 | Ghost link — underline draw | `transform: scaleX(0 → 1)`, `transform-origin: left center` | 300ms | ease-inout | hover · focus-visible (reverses on out) | full-width rule, instant |
| 04 | Nav text-roll pill | `transform: translateY(0 → -44px)` inside a 44px clip, radius 8px | 200ms | ease-inout | hover · focus-visible | inverted copy shown instantly |
| 05 | Media card — crop | inner `transform: scale(1 → 1.05)`, frame fixed + `overflow: hidden` | 600ms | ease-expo | hover · focus-visible | stays at `scale(1)` |
| 05 | Media card — caption | `transform: translateY(101% → 0)` | 500ms | ease-expo | hover · focus-visible | caption visible, no slide |
| 06 | Editorial row — content shift | `transform: translateX(0 → 8px)` | 400ms | ease-expo | hover · focus-visible | no shift |
| 06 | Editorial row — number | `color → --accent` | 300ms | ease-inout | hover · focus-visible | instant |
| 06 | Editorial row — hairline draw | accent overlay `scaleX(0 → 1)` from left | 400ms | ease-expo | hover · focus-visible | full-width instantly |
| 06 | Editorial row — arrow | `transform: translateX(0 → 6px)` | 400ms | ease-expo | hover · focus-visible | no shift |
| 07 | Custom cursor — follow | `transform: translate3d()`, lerp 0.22 per frame | rAF | — | `pointermove` inside `[data-cursor-zone]` | not rendered |
| 07 | Custom cursor — context scale | `transform: scale(1 → 4.5)` on the 12px dot | 300ms | ease-expo | pointer over `[data-cursor]` | not rendered |
| 07 | Custom cursor — label | `opacity 0 → 1` | 150ms | linear | pointer over `[data-cursor]` | not rendered |
| 08 | Marquee | `transform: translate3d(0 → -50%)`, two identical sets | 26s loop | linear | autoplay | static wrapped row, animation not applied |
| 08 | Marquee — pause | `animation-play-state: paused` | instant | — | hover · focus-within | already static |
| 09 | Accordion — panel | `grid-template-rows: 0fr → 1fr` | 300ms | ease-inout | click / Enter / Space on the header button | snaps open, no tween |
| 09 | Accordion — chevron | `transform: rotate(0 → 180deg)` | 300ms | ease-inout | same as panel | instant |
| 09 | Accordion — focus move | `.focus()` on prev/next header | instant | — | `ArrowUp` / `ArrowDown` / `Home` / `End` | unchanged |
| 10 | Page transition — outgoing | `opacity 1 → 0` | 250ms | ease-inout | route change | skipped, content swaps immediately |
| 10 | Page transition — incoming | `opacity 0 → 1` + `transform: translateY(12px → 0)` | 400ms | ease-expo | after outgoing completes and `scrollTop = 0` | skipped; scroll still resets |

## Rules enforced across all ten

- **Transform and opacity only** for motion. Two documented exceptions, both non-layout-thrashing: `background-color`/`color` on state changes (02, 06) and `grid-template-rows` on the accordion panel (09) — the accessible way to tween an unknown height without measuring or animating `height`.
- **focus-visible === hover.** Every state is driven from one delegated handler set (`mouseover` / `mouseout` / `focusin` / `focusout`) writing to a single `hot[id]` map, so there is exactly one visual state per interaction and no CSS/JS drift. Focus is filtered through `:focus-visible` so mouse clicks don't leave a stuck state.
- **Hit targets ≥ 44px.** Buttons 48px, nav pill 44px, ghost link 44px line box, accordion headers 64px, editorial rows 88px, marquee links 64px.
- **Reduced motion.** `prefers-reduced-motion: reduce` (or the `forceReducedMotion` tweak) sets every duration to 1ms, drops the custom cursor and the magnetic pull, renders the marquee as a static wrapped row, and swaps routes with no transition. Reduced motion never removes information — captions, underlines and accent hairlines still appear, just instantly.
- **Custom cursor never intercepts input:** `position: fixed`, `pointer-events: none`, and only rendered when `(pointer: fine)` matches.
- **No libraries.** Vanilla JS: one rAF spring for the magnet, one rAF lerp for the cursor, CSS transitions for everything else.

## Notes for implementation

- **Ghost link underline** is a real `aria-hidden` `<span>` rather than `::after`. Functionally identical (`scaleX` + `transform-origin: left`), but a real element can be driven by the same state as focus-visible without duplicating a rule set. Use `::after` if you prefer, with `:hover, :focus-visible { &::after { transform: scaleX(1) } }`.
- **Text-roll offset** is one row height in px (`-44px`), not `-100%`: the transformed element is the two-row stack (88px), so a percentage overshoots by a full row and leaves an empty window.
- **Text-roll duplicate** is a real `<span aria-hidden="true">`, never `content: attr(data-hover)` — attr() content is inconsistently exposed to assistive tech and cannot be translated.
- **Marquee** duplicates its set once and travels exactly `-50%`, so the seam is invisible at any width; the duplicate is `aria-hidden` and its links are removed from the tab order.
- **Page transition** resets scroll while the container is at `opacity: 0`, between the outgoing fade and the incoming rise — no visible jump, no wipe, no splash.

## Deviation from the requested file layout

This project builds designs as single streaming Design Components, so the demo page ships as `kit.dc.html` (markup + inline styles + the interaction logic in one file) instead of `kit.html` / `kit.css` / `kit.js`. Every timing is in the table above and printed beside its demo, so the numbers are copyable regardless of file split.
