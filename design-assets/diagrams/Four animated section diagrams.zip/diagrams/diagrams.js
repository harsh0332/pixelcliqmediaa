/* D2C growth agency — section diagrams
 * Four hairline SVG diagrams as self-contained custom elements.
 *   <commerce-flow> <performance-equation> <automation-schematic> <process-progression>
 * Vanilla JS, no dependencies. Also exposes window.OMDiagrams.render(name, mode)
 * which returns the static final-state SVG markup (used to generate /svg).
 */
(function () {
  'use strict';

  var C = { ink: '#14151A', muted: '#6B6C73', line: '#E2DDD3', accent: '#2C4BFF' };
  var FF = "Satoshi,'Helvetica Neue',Helvetica,Arial,sans-serif";
  /* Component mode omits every presentation attribute that CSS must own for state changes.
     Static export (window.OMDiagrams.render) keeps them, so the /svg files stand alone. */
  var LIVE = false;

  /* ---------- markup helpers (presentation attributes = final state) ---------- */
  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function at(o) { var s = '', k; for (k in o) { if (o[k] === null || o[k] === undefined) continue; s += ' ' + k + '="' + o[k] + '"'; } return s; }
  function T(n, a, inner) { return '<' + n + at(a) + (inner != null ? '>' + inner + '</' + n + '>' : '/>'); }
  function assign(a, b) { for (var k in b) a[k] = b[k]; return a; }

  function rect(x, y, w, h, a) {
    return T('rect', assign({ x: x + 0.5, y: y + 0.5, width: Math.max(0, w - 1), height: Math.max(0, h - 1), fill: 'none', stroke: C.line, 'stroke-width': 1 }, a || {}));
  }
  function line(x1, y1, x2, y2, a) {
    var h = y1 === y2, v = x1 === x2;
    return T('line', assign({ x1: v ? x1 + 0.5 : x1, y1: h ? y1 + 0.5 : y1, x2: v ? x1 + 0.5 : x2, y2: h ? y1 + 0.5 : y2, stroke: C.line, 'stroke-width': 1 }, a || {}));
  }
  function path(d, a) { return T('path', assign({ d: d, fill: 'none', stroke: C.line, 'stroke-width': 1 }, a || {})); }
  /* true path length, so curved draw-ins have exact dash geometry */
  function plen(d, fallback) {
    try {
      var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.setAttribute('style', 'position:absolute;width:0;height:0;overflow:hidden;visibility:hidden');
      var p = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      p.setAttribute('d', d);
      svg.appendChild(p);
      document.body.appendChild(svg);
      var L = p.getTotalLength();
      document.body.removeChild(svg);
      return L > 1 ? Math.ceil(L) + 2 : fallback;
    } catch (e) { return fallback; }
  }
  function abar(x, y, w, h) { return T('rect', { x: x, y: y, width: w, height: h, fill: LIVE ? null : C.accent, 'data-accent-fill': '' }); }
  function g(tr, inner, a) { return T('g', assign({ transform: tr }, a || {}), inner); }
  function txt(x, y, s, o) {
    o = o || {};
    return T('text', {
      x: x, y: y, fill: (LIVE && (o.name || o.num)) ? null : (o.fill || C.muted), 'text-anchor': o.anchor || null,
      'data-name': o.name ? '' : null, 'data-num': o.num ? '' : null,
      style: 'font:' + (o.weight || 500) + ' ' + (o.size || 11) + 'px ' + FF + ';letter-spacing:' + (o.ls == null ? 0.08 : o.ls) + 'em'
    }, esc(s));
  }
  function svgWrap(w, h, maxw, inner) {
    return T('svg', {
      xmlns: 'http://www.w3.org/2000/svg', viewBox: '0 0 ' + w + ' ' + h,
      width: w, height: h, role: 'presentation', 'aria-hidden': 'true',
      style: 'display:block;width:100%;height:auto;max-width:' + maxw + 'px'
    }, inner);
  }
  function srList(items, ordered) {
    var tagName = ordered ? 'ol' : 'ul';
    return '<' + tagName + ' class="sr">' + items.map(function (i) { return '<li>' + esc(i) + '</li>'; }).join('') + '</' + tagName + '>';
  }

  /* ======================================================================
   * DIAGRAM 1 — COMMERCE FLOW
   * ==================================================================== */
  var FLOW = [
    ['AD', 'hook'], ['LANDING PAGE', 'message match'], ['PDP', 'objection handling'],
    ['CART', 'friction'], ['CHECKOUT', 'trust'], ['RETENTION', 'repeat rate']
  ];
  var BW = 140, BH = 96, F_STEP = 233;

  function wire(i) {
    var o = [], k;
    if (i === 0) { o.push(rect(12, 12, 116, 40), line(12, 64, 92, 64), line(12, 76, 64, 76), abar(12, 84, 22, 4)); }
    if (i === 1) { o.push(line(12, 18, 128, 18), rect(12, 26, 116, 30), line(12, 66, 100, 66), line(12, 76, 70, 76), abar(12, 84, 26, 4)); }
    if (i === 2) { o.push(rect(12, 12, 52, 52), line(72, 20, 128, 20), line(72, 32, 112, 32), line(72, 44, 120, 44), abar(72, 54, 26, 4), line(12, 76, 128, 76), line(12, 86, 90, 86)); }
    if (i === 3) { for (k = 0; k < 3; k++) { o.push(rect(12, 14 + k * 22, 16, 16), line(36, 22 + k * 22, 128, 22 + k * 22)); } o.push(line(12, 84, 60, 84), abar(102, 82, 26, 4)); }
    if (i === 4) { for (k = 0; k < 3; k++) o.push(rect(12, 14 + k * 20, 116, 12)); o.push(line(12, 72, 72, 72), abar(12, 80, 32, 4)); }
    if (i === 5) { o.push(rect(12, 12, 116, 22), line(12, 46, 96, 46), line(12, 56, 76, 56), rect(12, 66, 16, 16), rect(34, 66, 16, 16), abar(56, 72, 24, 4)); }
    return rect(0, 0, BW, BH, { 'data-node': '', stroke: LIVE ? null : C.line, style: '--d:' + (i * F_STEP) + 'ms' }) + o.join('');
  }

  function arrow(x, y, len, vertical) {
    // hairline base + accent overlay that draws in
    var d = vertical
      ? 'M' + (x + 0.5) + ' ' + y + 'V' + (y + len) + 'M' + (x + 0.5 - 4) + ' ' + (y + len - 6) + 'L' + (x + 0.5) + ' ' + (y + len) + 'L' + (x + 0.5 + 4) + ' ' + (y + len - 6)
      : 'M' + x + ' ' + (y + 0.5) + 'H' + (x + len) + 'M' + (x + len - 6) + ' ' + (y + 0.5 - 4) + 'L' + (x + len) + ' ' + (y + 0.5) + 'L' + (x + len - 6) + ' ' + (y + 0.5 + 4);
    return { base: path(d), d: d, len: len + 16 };
  }

  function svgFlow(mode) {
    var m = mode === 'v', out = [], i, L, a, s = 0.92;
    if (!m) {
      var gap = 64, W = 6 * BW + 5 * gap;
      for (i = 0; i < 6; i++) {
        var bx = i * (BW + gap);
        out.push(g('translate(' + bx + ',0)', wire(i)));
        out.push(txt(bx, BH + 28, FLOW[i][0], { fill: C.ink, size: 12, ls: 0.1, name: true }));
        out.push('<text x="' + bx + '" y="' + (BH + 48) + '" fill="' + C.muted + '" style="font:400 13px ' + FF + ';letter-spacing:0em">' + esc(FLOW[i][1]) + '</text>');
        if (i < 5) {
          a = arrow(bx + BW + 10, BH / 2, gap - 20, false);
          out.push(a.base, path(a.d, { stroke: LIVE ? null : C.accent, 'data-accent': '', 'data-draw': '', style: '--len:' + a.len + ';--d:' + (i * F_STEP + 90) + 'ms;--dur:200ms' }));
        }
      }
      return svgWrap(W, BH + 58, W, out.join(''));
    }
    var vgap = 54, bh = BH * s, lx = BW * s / 2 - 0.5;
    for (i = 0; i < 6; i++) {
      var by = i * (bh + vgap);
      out.push(g('translate(0,' + by + ') scale(' + s + ')', wire(i)));
      out.push(txt(BW * s + 22, by + bh / 2 - 3, FLOW[i][0], { fill: C.ink, size: 12, ls: 0.1, name: true }));
      out.push('<text x="' + (BW * s + 22) + '" y="' + (by + bh / 2 + 17) + '" fill="' + C.muted + '" style="font:400 13px ' + FF + ';letter-spacing:0em">' + esc(FLOW[i][1]) + '</text>');
      if (i < 5) {
        a = arrow(lx, by + bh + 10, vgap - 20, true);
        out.push(a.base, path(a.d, { stroke: LIVE ? null : C.accent, 'data-accent': '', 'data-draw': '', style: '--len:' + a.len + ';--d:' + (i * F_STEP + 90) + 'ms;--dur:200ms' }));
      }
    }
    return svgWrap(358, 6 * (bh + vgap) - vgap + 4, 358, out.join(''));
  }

  /* ======================================================================
   * DIAGRAM 2 — PERFORMANCE EQUATION
   * ==================================================================== */
  var EQ = ['Creative', 'Media', 'Landing page', 'Offer', 'Tracking', 'Retention'];

  function svgEq(mode) {
    var m = mode === 'v', W = m ? 358 : 560, rowH = m ? 46 : 54, size = m ? 19 : 23, out = [], i;
    for (i = 0; i < 6; i++) {
      var y = i * rowH, inner = txt(0, y + rowH * 0.64, EQ[i], { fill: C.ink, size: size, ls: -0.01, weight: 500 });
      if (i < 5) inner += txt(W, y + rowH * 0.64, '+', { fill: C.muted, size: size, ls: 0, anchor: 'end' });
      inner += line(0, y + rowH, W, y + rowH);
      out.push(g(null, inner, { 'data-row': '', style: '--d:' + (i * 50) + 'ms' }));
    }
    var ry = 6 * rowH + 16;
    out.push(path('M0 ' + (ry + 0.5) + 'H' + W, { stroke: C.ink, 'data-draw': '', style: '--len:' + (W + 4) + ';--d:620ms;--dur:340ms' }));
    out.push(T('g', { 'data-result': '', style: '--d:940ms' },
      txt(0, ry + 44, '= Profitable scale', { fill: C.accent, size: size, ls: -0.01, weight: 500 })));
    return svgWrap(W, ry + 62, W, out.join(''));
  }

  /* ======================================================================
   * DIAGRAM 3 — AUTOMATION SCHEMATIC
   * ==================================================================== */
  var AUTO = ['LEAD', 'QUALIFY', 'ROUTE', 'FOLLOW UP', 'CRM', 'REPORT'];
  var SQ = 18, A_STEP = 267;

  function svgAuto(mode) {
    var m = mode === 'v';
    var railA = 26, railB = m ? 88 : 132, step = m ? 76 : 82, top = 18;
    var W = m ? 358 : 400, i, out = [], chain = [];
    var nx = function (i) { return (i % 2) ? railB : railA; };
    var ny = function (i) { return top + i * step; };

    for (i = 0; i < 5; i++) {
      var x1 = nx(i) + SQ / 2 + 0.5, x2 = nx(i + 1) + SQ / 2 + 0.5;
      var yA = ny(i) + SQ, yB = ny(i) + SQ + (step - SQ) / 2 + 0.5, yC = ny(i + 1);
      out.push(path('M' + x1 + ' ' + yA + 'V' + yB + 'H' + x2 + 'V' + yC));
      out.push(T('circle', { cx: x1, cy: yB, r: 2, fill: LIVE ? null : C.accent, 'data-accent-fill': '', 'data-dot': '', style: '--d:' + (i * A_STEP + 110) + 'ms' }));
      out.push(T('circle', { cx: x2, cy: yB, r: 2, fill: LIVE ? null : C.accent, 'data-accent-fill': '', 'data-dot': '', style: '--d:' + (i * A_STEP + 190) + 'ms' }));
      chain.push((i === 0 ? 'M' + x1 + ' ' + (ny(0) + 0.5) + 'V' + yA : '') + 'V' + yB + 'H' + x2 + 'V' + yC + 'V' + (yC + SQ));
    }
    for (i = 0; i < 6; i++) {
      out.push(rect(nx(i), ny(i), SQ, SQ, { 'data-node': '', stroke: LIVE ? null : C.line, style: '--d:' + (i * A_STEP) + 'ms' }));
      out.push(txt(nx(i) + SQ + 16, ny(i) + 13, AUTO[i], { fill: C.ink, size: 11, ls: 0.16, name: true }));
    }
    var chainD = chain.join('');
    var L = plen(chainD, 1600);
    out.push(path(chainD, { stroke: LIVE ? null : C.accent, 'data-accent': '', 'data-pulse': '', 'stroke-linecap': 'round', style: '--L:' + L }));
    return svgWrap(W, ny(5) + SQ + 20, W, out.join(''));
  }

  /* ======================================================================
   * DIAGRAM 4 — PROCESS PROGRESSION (scroll-linked)
   * ==================================================================== */
  var STEPS = [['01', 'AUDIT'], ['02', 'STRATEGY'], ['03', 'BUILD'], ['04', 'LAUNCH'], ['05', 'COMPOUND']];
  var TRACK_END = 0.82;

  function marker(x, y, num, name, mode) {
    var m = mode === 'v', inner = T('circle', { cx: x, cy: y, r: 9, fill: 'none', stroke: LIVE ? null : C.accent, 'stroke-width': 1, 'data-ring': '' })
      + T('circle', { cx: x, cy: y, r: 3.5, fill: LIVE ? null : C.accent, 'data-accent-fill': '', 'data-core': '', opacity: LIVE ? null : 1 });
    if (m) {
      inner += txt(x + 26, y + 4, num, { fill: C.ink, size: 12, ls: 0.1, num: true });
      inner += txt(x + 58, y + 4, name, { fill: C.muted, size: 12, ls: 0.14 });
    } else {
      inner += txt(x, y + 34, num, { fill: C.ink, size: 12, ls: 0.1, anchor: 'middle', num: true });
      inner += txt(x, y + 54, name, { fill: C.muted, size: 12, ls: 0.14, anchor: 'middle' });
    }
    return T('g', { 'data-mk': '', 'data-on': '' }, inner);
  }

  function svgProc(mode) {
    var m = mode === 'v', out = [], i, gx = [];
    if (!m) {
      var W = 1160, y = 78, x0 = 26, x1 = W - 26, sp = (x1 - x0) / 4;
      for (i = 0; i < 5; i++) gx.push(x0 + i * sp);
      out.push(line(x0, y, x1, y));
      out.push(path('M' + x0 + ' ' + (y + 0.5) + 'H' + x1, { stroke: LIVE ? null : C.accent, 'data-accent': '', 'data-track': '', style: '--len:' + (x1 - x0) }));
      var rd = 'M' + x1 + ' ' + (y - 15) + 'C' + x1 + ' ' + 22 + ' ' + (x1 - 130) + ' 14 ' + (W * 0.5) + ' 14C' + (x0 + 130) + ' 14 ' + x0 + ' 22 ' + x0 + ' ' + (y - 15) + 'M' + (x0 - 5) + ' ' + (y - 23) + 'L' + x0 + ' ' + (y - 15) + 'L' + (x0 + 5) + ' ' + (y - 23);
      out.push(path(rd, { stroke: LIVE ? null : C.accent, 'data-accent': '', 'data-return': '', style: '--len:' + plen(rd, 1300) }));
      for (i = 0; i < 5; i++) out.push(marker(gx[i], y, STEPS[i][0], STEPS[i][1], mode));
      return svgWrap(W, y + 66, W, out.join(''));
    }
    var W2 = 358, x = 22, y0 = 22, spv = 92, yEnd = y0 + 4 * spv;
    out.push(line(x, y0, x, yEnd));
    out.push(path('M' + (x + 0.5) + ' ' + y0 + 'V' + yEnd, { stroke: LIVE ? null : C.accent, 'data-accent': '', 'data-track': '', style: '--len:' + (yEnd - y0) }));
    var rdv = 'M' + (x + 15) + ' ' + yEnd + 'C' + (x + 76) + ' ' + yEnd + ' ' + (x + 84) + ' ' + (yEnd - 90) + ' ' + (x + 84) + ' ' + ((y0 + yEnd) / 2)
      + 'C' + (x + 84) + ' ' + (y0 + 90) + ' ' + (x + 76) + ' ' + y0 + ' ' + (x + 15) + ' ' + y0
      + 'M' + (x + 23) + ' ' + (y0 - 5) + 'L' + (x + 15) + ' ' + y0 + 'L' + (x + 23) + ' ' + (y0 + 5);
    out.push(path(rdv, { stroke: LIVE ? null : C.accent, 'data-accent': '', 'data-return': '', style: '--len:' + plen(rdv, 640) }));
    for (i = 0; i < 5; i++) out.push(marker(x + 0.5, y0 + i * spv, STEPS[i][0], STEPS[i][1], mode));
    return svgWrap(W2, yEnd + 24, W2, out.join(''));
  }

  /* ======================================================================
   * shared shadow CSS
   * ==================================================================== */
  var CSS = ':host{display:block;position:relative}'
    + 'svg{display:block;width:100%;height:auto;margin:0 auto;overflow:visible}'
    + 'svg *{vector-effect:non-scaling-stroke}'
    + '[data-node]{stroke:#14151A}[data-name]{fill:#14151A}'
    + '[data-mk] [data-ring]{stroke:#E2DDD3}[data-mk] [data-core]{opacity:0;fill:var(--accent,#2C4BFF)}[data-mk] [data-num]{fill:#6B6C73}'
    + '[data-on] [data-ring]{stroke:var(--accent,#2C4BFF)}[data-on] [data-core]{opacity:1}[data-on] [data-num]{fill:#14151A}'
    + '[data-accent]{stroke:var(--accent,#2C4BFF)}'
    + '[data-accent-fill]{fill:var(--accent,#2C4BFF)}'
    + '.sr{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip-path:inset(50%);border:0;white-space:nowrap}'
    + '[data-draw],[data-track],[data-return]{stroke-dasharray:var(--len)}'
    + ':host([anim]) [data-draw]{stroke-dashoffset:var(--len)}'
    + ':host([anim]) [data-node]{stroke:#E2DDD3}'
    + ':host([anim]) [data-name]{fill:#6B6C73}'
    + ':host([anim]) [data-dot]{opacity:0}'
    + ':host([anim]) [data-row]{opacity:0;transform:translateY(9px)}'
    + ':host([anim]) [data-result]{opacity:0}'
    + ':host([play]) [data-draw]{animation:dg var(--dur,240ms) cubic-bezier(.33,.05,.5,1) both;animation-delay:var(--d,0ms)}'
    + ':host([play]) [data-node]{animation:nk 200ms linear both;animation-delay:var(--d,0ms)}'
    + ':host([play]) [data-name]{animation:nf 200ms linear both;animation-delay:var(--d,0ms)}'
    + ':host([play]) [data-dot]{animation:fd 160ms linear both;animation-delay:var(--d,0ms)}'
    + ':host([play]) [data-row]{animation:rw 340ms cubic-bezier(.22,.61,.36,1) both;animation-delay:var(--d,0ms)}'
    + ':host([play]) [data-result]{animation:fd 280ms linear both;animation-delay:var(--d,0ms)}'
    + '[data-pulse]{opacity:0;stroke-dasharray:44 9999}'
    + ':host([play]) [data-pulse]{animation:pl 1600ms cubic-bezier(.42,0,.58,1) both}'
    + '@keyframes dg{to{stroke-dashoffset:0}}'
    + '@keyframes nk{to{stroke:#14151A}}'
    + '@keyframes nf{to{fill:#14151A}}'
    + '@keyframes fd{from{opacity:0}to{opacity:1}}'
    + '@keyframes rw{to{opacity:1;transform:none}}'
    + '@keyframes pl{0%{opacity:1;stroke-dashoffset:0}97%{opacity:1}100%{opacity:0;stroke-dashoffset:calc(-1px * (var(--L) + 44))}}'
    + '[data-mk] [data-ring],[data-mk] [data-core],[data-mk] [data-num]{transition:stroke .26s ease,opacity .26s ease,fill .26s ease}';

  function reduced() { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } }

  /* ======================================================================
   * base element
   * ==================================================================== */
  var Base = function () { };
  Base.proto = {
    buildSvg: function () { LIVE = true; try { return this.svg(this._mode); } finally { LIVE = false; } },
    connectedCallback: function () {
      if (this._built) return;
      this._built = true;
      this.attachShadow({ mode: 'open' });
      this._mode = this.pickMode();
      this._reduced = reduced();
      this.shadowRoot.innerHTML = '<style>' + CSS + '</style><div data-viz aria-hidden="true">' + this.buildSvg() + '</div>' + this.list();
      if (!this._reduced && !this.scrollLinked) this.setAttribute('anim', '');
      if (this.afterBuild) this.afterBuild();
      if (this.scrollLinked) this.bindScroll();
      else if (!this._reduced) this.observe();
      var self = this;
      if (window.ResizeObserver) {
        this._ro = new ResizeObserver(function () {
          var m = self.pickMode();
          /* deferred so the rebuild's own size change doesn't re-enter the observer */
          if (m !== self._mode) { self._mode = m; setTimeout(function () { self.rebuild(); }, 0); }
        });
        this._ro.observe(this);
      }
    },
    disconnectedCallback: function () {
      if (this._ro) this._ro.disconnect();
      if (this._io) this._io.disconnect();
      if (this._onScroll) { window.removeEventListener('scroll', this._onScroll); window.removeEventListener('resize', this._onScroll); document.removeEventListener('scroll', this._onScroll, true); }
    },
    pickMode: function () { var w = this.clientWidth || (this.parentElement && this.parentElement.clientWidth) || 1440; return w < 560 ? 'v' : 'h'; },
    rebuild: function () {
      var wasPlayed = this.hasAttribute('play');
      this.shadowRoot.querySelector('[data-viz]').innerHTML = this.buildSvg();
      if (wasPlayed) { this.removeAttribute('play'); this.removeAttribute('anim'); }
      if (this.afterBuild) this.afterBuild();
      if (this.scrollLinked) this.measure();
    },
    observe: function () {
      var self = this;
      this._io = new IntersectionObserver(function (entries) {
        for (var i = 0; i < entries.length; i++) {
          var e = entries[i];
          var vh = window.innerHeight || 1;
          if (e.isIntersecting && (e.intersectionRatio >= 0.2 || e.intersectionRect.height >= vh * 0.6)) {
            self._io.disconnect(); self._io = null;
            self.setAttribute('play', '');
            return;
          }
        }
      }, { threshold: [0, 0.2, 0.4, 0.8] });
      this._io.observe(this);
    },
    /* review-harness affordance: the diagrams never re-trigger on their own */
    replay: function () {
      if (this._reduced || this.scrollLinked) return;
      this.removeAttribute('play');
      this.setAttribute('anim', '');
      void this.offsetWidth;
      var self = this;
      requestAnimationFrame(function () { self.setAttribute('play', ''); });
    }
  };

  function define(name, spec) {
    var Klass = function () { return Reflect.construct(HTMLElement, [], Klass); };
    Klass.prototype = Object.create(HTMLElement.prototype);
    Klass.prototype.constructor = Klass;
    assign(Klass.prototype, Base.proto);
    assign(Klass.prototype, spec);
    Object.setPrototypeOf(Klass, HTMLElement);
    if (!customElements.get(name)) customElements.define(name, Klass);
    return Klass;
  }

  define('commerce-flow', {
    svg: function (m) { return svgFlow(m); },
    list: function () {
      return '<p class="sr">Conversion path, six stages, each with the lever optimised there.</p>' +
        srList(FLOW.map(function (f) { return f[0].toLowerCase() + ' — ' + f[1]; }), true);
    }
  });

  define('performance-equation', {
    svg: function (m) { return svgEq(m); },
    list: function () {
      return '<p class="sr">Performance equation.</p>' + srList(EQ.concat(['equals profitable scale']), false);
    }
  });

  define('automation-schematic', {
    svg: function (m) { return svgAuto(m); },
    list: function () {
      return '<p class="sr">Automation path, six stages.</p>' + srList(AUTO.map(function (a) { return a.toLowerCase(); }), true);
    }
  });

  define('process-progression', {
    scrollLinked: true,
    svg: function (m) { return svgProc(m); },
    list: function () {
      return '<p class="sr">Engagement process, five steps, the last one compounding back into the first.</p>' +
        srList(STEPS.map(function (s) { return s[0] + ' ' + s[1].toLowerCase(); }), true);
    },
    afterBuild: function () {
      var r = this.shadowRoot;
      this._track = r.querySelector('[data-track]');
      this._return = r.querySelector('[data-return]');
      this._marks = [].slice.call(r.querySelectorAll('[data-mk]'));
      this.apply(this._reduced ? 1 : (this._p || 0));
    },
    bindScroll: function () {
      var self = this;
      this._onScroll = function () { self.measure(); };
      window.addEventListener('scroll', this._onScroll, { passive: true });
      window.addEventListener('resize', this._onScroll);
      /* also catch scrolls on an ancestor scroll container, not just the window */
      document.addEventListener('scroll', this._onScroll, { capture: true, passive: true });
      this.measure();
    },
    measure: function () {
      if (this._reduced) { this.apply(1); return; }
      var r = this.getBoundingClientRect(), vh = window.innerHeight || 1;
      var start = vh * 0.9, end = vh * 0.28;
      var p = (start - r.top) / (start - end);
      this.apply(Math.max(0, Math.min(1, p)));
    },
    /* normalised 0 -> 1 progress */
    apply: function (p) {
      this._p = p;
      this.style.setProperty('--progress', p.toFixed(4));
      if (this._track) {
        var t = Math.min(1, p / TRACK_END), len = parseFloat(getComputedStyle(this._track).getPropertyValue('--len')) || 0;
        this._track.style.strokeDashoffset = (len * (1 - t)).toFixed(2);
      }
      if (this._return) {
        var q = Math.max(0, Math.min(1, (p - TRACK_END) / (1 - TRACK_END)));
        var rl = parseFloat(getComputedStyle(this._return).getPropertyValue('--len')) || 0;
        this._return.style.strokeDashoffset = (rl * (1 - q)).toFixed(2);
      }
      if (this._marks) {
        for (var i = 0; i < this._marks.length; i++) {
          var th = (i / 4) * TRACK_END;
          if (i === 0) th = 0.015;
          if (p >= th) this._marks[i].setAttribute('data-on', ''); else this._marks[i].removeAttribute('data-on');
        }
      }
      this.dispatchEvent(new CustomEvent('diagram:progress', { detail: { progress: p } }));
    }
  });

  Object.defineProperty(customElements.get('process-progression').prototype, 'progress', {
    get: function () { return this._p || 0; }
  });

  /* static final-state export (used to generate /svg) */
  window.OMDiagrams = {
    render: function (name, mode) {
      mode = mode || 'h';
      if (name === 'commerce-flow') return svgFlow(mode);
      if (name === 'performance-equation') return svgEq(mode);
      if (name === 'automation-schematic') return svgAuto(mode);
      if (name === 'process-progression') return svgProc(mode);
      return '';
    }
  };
})();
