# Section diagrams — motion & implementation spec

Four diagrams, one family, four different structures. Hairline SVG only: 1px strokes,
no fills except small accent markers, no icons, no 3D, no gradients, no shadows.

**No diagram contains a number, percentage, currency figure or axis value.** The only
numerals anywhere are the ordinal step labels `01`–`05` in Diagram 04, which are names,
not values.

## Tokens

| token | value | use |
| --- | --- | --- |
| `--ink` | `#14151A` | activated labels, summary rule |
| `--ink-muted` | `#6B6C73` | pre-activation labels, secondary words, operators |
| `--bone` | `#F7F5F0` | diagram surface |
| `--sand` | `#EFEBE3` | page surface behind the frames |
| `--line` | `#E2DDD3` | all hairline linework |
| `--accent` | `#2C4BFF` | draw-in lines, junction dots, markers |

Type: Satoshi 500, small. `letter-spacing: 0.08em` default; `0.10em` on flow node names
and step numbers; `0.14–0.16em` on the schematic and process step names (wide-tracked,
uppercase). Fallback stack `'Helvetica Neue', Helvetica, Arial, sans-serif`.

All strokes carry `vector-effect: non-scaling-stroke`, so hairlines stay exactly 1px at
any container width.

## Files

```
/diagrams
  commerce-flow.html          diagram 01, shown at 1440 and 390
  performance-equation.html   diagram 02
  automation-schematic.html   diagram 03
  process-progression.html    diagram 04
  diagrams.css                page chrome + tokens only (diagrams are shadow-encapsulated)
  diagrams.js                 all four diagrams as custom elements
  /svg                        static final-state SVG per diagram, desktop + mobile
  SPEC.md
```

Custom elements: `<commerce-flow>`, `<performance-equation>`, `<automation-schematic>`,
`<process-progression>`. Each builds its own shadow root, needs no attributes, and reads
`--accent` (and nothing else) from the host page, so the accent is themeable per section.

Mode switching is by **element width**, not media query: `< 560px` → vertical variant.
A `ResizeObserver` rebuilds the geometry on crossing that threshold. If the diagram had
already played, the rebuild renders the final state instantly rather than replaying.

---

## Diagram 01 — Commerce flow

Structure: six nodes left to right — AD → LANDING PAGE → PDP → CART → CHECKOUT →
RETENTION. Each node is a 140×96 hairline wireframe block (a suggestion of a screen, with
a different internal arrangement per stage) plus one small accent marker. Beneath each
block: the node name (tracked, uppercase) and a single lowercase word — *hook, message
match, objection handling, friction, trust, repeat rate*.

| property | value |
| --- | --- |
| trigger | `IntersectionObserver`, fires once at `intersectionRatio >= 0.2` (or ≥ 60% of viewport height visible, for the tall mobile variant); observer disconnects on fire |
| total | ~1455ms |
| step | 233ms per node (`6 × 233 ≈ 1400`) |
| connector draw | `stroke-dashoffset` → 0, 200ms, `cubic-bezier(.33,.05,.5,1)`, delay `i × 233 + 90ms` (arrowhead is part of the same path, so it lands with the segment) |
| node activation | block stroke `--line` → `--ink`, 200ms linear, delay `i × 233ms` |
| label activation | name fill `--ink-muted` → `--ink`, 200ms linear, delay `i × 233ms` |
| lowercase word | static `--ink-muted`, never animates |
| mobile (<560) | single column, blocks at 0.92 scale, name + word to the right of each block; connectors rotate to vertical with a downward arrowhead; identical delays |
| reduced motion | no `anim` attribute is set, so every element renders at its authored final state on first paint: all blocks and names in `--ink`, all connectors fully drawn in accent |
| replay | `element.replay()` — harness affordance only; the diagram never re-triggers itself |

## Diagram 02 — Performance equation

Structure: type only, no graphic. Six hairline rows — Creative, Media, Landing page,
Offer, Tracking, Retention — each with a right-aligned `+` except the last, each closed by
a hairline. A summary rule, then `= Profitable scale` in accent.

| property | value |
| --- | --- |
| trigger | `IntersectionObserver`, once at 20% |
| total | ~1200ms |
| row reveal | opacity 0 → 1 + `translateY(9px)` → 0, 340ms, `cubic-bezier(.22,.61,.36,1)`, stagger 50ms (`--d: i × 50ms`) — the row hairline travels with the row |
| summary rule | `stroke-dashoffset` → 0 left to right, 340ms, delay 620ms, stroke `--ink` |
| result line | opacity 0 → 1, 280ms linear, delay 940ms, fill `--accent` |
| mobile (<560) | same stack, 358 wide, 19px type, 46px rows |
| reduced motion | rows, rule and result all render at final state instantly |

## Diagram 03 — Automation schematic

Structure: LEAD → QUALIFY → ROUTE → FOLLOW UP → CRM → REPORT as 18×18 hairline squares
alternating between two rails, connected by orthogonal runs (down, across, down) with a
2px accent dot at each of the two junctions per run. Labels are wide-tracked uppercase, set
to the right of each square, clear of the routing. Engineering drawing, not marketing
graphic — no robot icons, brains, sparkles, badges, glows or neon.

| property | value |
| --- | --- |
| trigger | `IntersectionObserver`, once at 20% |
| total | 1600ms |
| step | 267ms per node (`6 × 267 ≈ 1600`) |
| pulse | one accent path along the whole chain, `stroke-dasharray: 44 9999`, offset 0 → `-(L + 44)`, 1600ms, `cubic-bezier(.42,0,.58,1)`, `fill-mode: both`, **iteration-count 1** — the dash is off the end of the path at rest, and opacity drops to 0 in the last 3% so nothing lingers |
| node activation | square stroke `--line` → `--ink`, 200ms linear, delay `i × 267ms` |
| label activation | fill `--ink-muted` → `--ink`, 200ms linear, delay `i × 267ms` |
| junction dots | opacity 0 → 1, 160ms linear, delays `i × 267 + 110ms` and `i × 267 + 190ms` |
| mobile (<560) | narrower rails (26 / 88) and 76px vertical step; same routing logic, same delays |
| reduced motion | nodes, labels and junction dots at final state; pulse stays at `opacity: 0` (it is motion, and carries no information the static state lacks) |

## Diagram 04 — Process progression

Structure: five markers on a horizontal line — 01 AUDIT, 02 STRATEGY, 03 BUILD, 04 LAUNCH,
05 COMPOUND. Each marker is a 9px hairline circle with a 3.5px accent core, the number
below it, the step name below that. A wide, quiet curve leaves 05, arcs above the line and
returns with a small arrowhead into 01.

| property | value |
| --- | --- |
| trigger | scroll-linked, not timed. `scroll` + `resize` on `window`, coalesced through `requestAnimationFrame` |
| progress | `p = clamp01((0.9·vh − rect.top) / (0.9·vh − 0.28·vh))` — 0 when the diagram's top sits at 90% of viewport height, 1 at 28% |
| exposure | mirrored three ways: `element.progress` (getter), the `--progress` custom property on the host, and a `diagram:progress` event with `detail.progress` |
| main line | `stroke-dashoffset = len × (1 − min(1, p / 0.82))` — drawn by the time `p` reaches 0.82 |
| marker activation | marker `i` turns on at `p >= (i / 4) × 0.82` (marker 01 at `p >= 0.015` so it reads as the origin); ring goes `--line` → `--accent`, core opacity 0 → 1, number `--ink-muted` → `--ink`, 260ms ease transition |
| return curve | drawn over `p` 0.82 → 1.0, same dashoffset mapping, so it is always last |
| mobile (<560) | line runs down the left at x=22, 92px step; number and name sit to the right of each marker; return curve loops out to the right and back to 01 |
| reduced motion | `measure()` short-circuits to `apply(1)` — line, all five markers and the return curve fully rendered, no scroll dependency |

---

## Accessibility

Every diagram's SVG is `aria-hidden="true"` with `role="presentation"`, and the real
content sits alongside inside the same shadow root as a visually-hidden semantic list:
an ordered list where sequence is meaningful (01, 03, 04), an unordered list for the
equation, each preceded by a one-line description. Nothing in the linework is the sole
carrier of meaning.

## Reduced motion, in one sentence

Nothing is animated *into* existence: the authored SVG **is** the final state, and the
animations are opt-in overrides applied only when the host element carries the `anim`
attribute, which `prefers-reduced-motion: reduce` prevents. Diagram 04 additionally pins
its progress to 1.
