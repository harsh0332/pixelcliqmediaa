# The Compound Loop — build spec

One scroll-linked section. Seven stages draw themselves into a closed loop.
Everything in it is driven by **one normalised value, `progress` 0 → 1**.

## Files

| File | What it is |
|---|---|
| `Compound Loop.dc.html` | The real thing. Desktop ring + tablet + mobile timeline, all breakpoints. |
| `Loop Heptagon.dc.html` | Shape study B (chosen), final state only. |
| `Loop Circle.dc.html` | Shape study A (rejected), final state only. |
| `loop.js` | The same scroll binding, framework-free and exportable. Read this for the port. |
| `loop.css` | Only what can't be inlined: tokens, breakpoints, `@keyframes loopPulse`, reduced motion. |
| `loop-static.svg` | The fully-drawn final state as a flat asset (`/about`, OG images, print). |

## Colour

| Token | Value | Note |
|---|---|---|
| `--ink` | `#14151A` | section background |
| `--bone` | `#F7F5F0` | primary text |
| `--accent` | `#5A78FF` | **lightened from `#2C4BFF`** |
| `--accent-glow` | `rgba(90,120,255,0.16)` | marker halo |
| `--line` | `rgba(247,245,240,0.055)` | ghost track |

`#2C4BFF` on `#14151A` is **3.14:1** — too thin for a 1.5px hairline and for 11px numerals.
Same hue, lifted lightness: `#5A78FF` = **4.86:1**. Use it for the stroke, the numbers and the markers.
Muted label state is `rgba(247,245,240,0.34)`; muted one-liner is `opacity: 0`.

## Type

- Stage labels — Clash Display 500, uppercase, `letter-spacing: 0.02em`, `max(21px, 2.5cqw)`
- One-liners / body — Satoshi 400, `max(13px, 1.45cqw)`
- Numbers 01–07 — Satoshi 500, uppercase, `letter-spacing: 0.12em`, `max(11px, 1cqw)`
- Centre statement — Clash Display 500, `max(20px, 2.6cqw)`

`cqw` units against the square loop container (`container-type: inline-size`) mean the whole
diagram scales as one object; the `max()` floors stop small text going illegible on a short viewport.

## Geometry — rounded heptagon

Design space: `viewBox="0 0 1200 1200"`, centre `600,600`, vertex radius `R = 340`.
Vertices every `360/7 = 51.4286°` starting at `-90°` (top).

| # | Vertex (unrounded) |
|---|---|
| V0 | 600.0, 260.0 |
| V1 | 865.8, 388.0 |
| V2 | 931.5, 675.7 |
| V3 | 747.5, 906.3 |
| V4 | 452.5, 906.3 |
| V5 | 268.5, 675.7 |
| V6 | 334.2, 388.0 |

Corners are quadratic Béziers with the control point **at the vertex** and the trim distance
`d = 48` along each edge (edge length `2R·sin(π/7) = 295`). That pulls the curve to `R ≈ 329.6`
at each corner — this is why node markers sit at `R·0.9694`, not `R`.

```
M 643.3 280.8 L 822.6 367.2 Q 865.8 388 876.5 434.8
L 920.8 628.9 Q 931.5 675.7 901.6 713.2
L 777.4 868.8 Q 747.5 906.3 699.5 906.3
L 500.5 906.3 Q 452.5 906.3 422.6 868.8
L 298.4 713.2 Q 268.5 675.7 279.2 628.9
L 323.5 434.8 Q 334.2 388 377.4 367.2
L 556.7 280.8 Q 600 260 643.3 280.8 Z
```

Path starts just clockwise of the top vertex and runs clockwise. Total length ≈ **2021** units,
but the path carries `pathLength="1"`, so all dash maths is in 0→1 and resolution-independent.

Circle alternative (rejected): `<circle cx="600" cy="600" r="340" transform="rotate(-90 600 600)">`,
same node angles, markers at `R` exactly, node fractions exactly `i/7`.

## Node positions

Marker centre as a percentage of the square container (this is what the `<li>`s use):

| # | Stage | left | top | fraction along path |
|---|---|---|---|---|
| 01 | Creative | 50.00% | 22.53% | 0.0000 |
| 02 | Media | 71.48% | 32.88% | 0.1207 |
| 03 | Commerce | 76.78% | 56.12% | 0.2636 |
| 04 | Conversion | 61.92% | 74.75% | 0.4064 |
| 05 | Retention | 38.08% | 74.75% | 0.5493 |
| 06 | Data | 23.23% | 56.12% | 0.6922 |
| 07 | Automation | 28.53% | 32.88% | 0.8350 |

Fractions are measured from the path start, so 02–07 sit `0.1207 + (i−1)/7`. Node 01 is at `0`
(and again at `1.0`, where the line returns to it — that return **is** the message).

Text blocks are offset radially from the marker by `2.9cqw`: node 01 above and centred (`24cqw`),
02–04 to the right (`21cqw`, left-aligned), 05–07 to the left (`21cqw`, right-aligned).

## Scroll progress

```
wrap    height: calc(100vh + var(--pin))     desktop --pin: 300vh, tablet 200vh, mobile none
sticky  position: sticky; top: 0; height: 100vh

progress = clamp01( -wrap.getBoundingClientRect().top / (wrap.height - innerHeight) )
```

Rect-relative, so it survives being nested in any scroll container.
Framer Motion equivalent, exactly:

```js
const { scrollYProgress: progress } = useScroll({
  target: wrapRef, offset: ["start start", "end end"],
});
```

### Thresholds

| Constant | Value | Meaning |
|---|---|---|
| `DRAW_START` | `0.02` | line begins |
| `DRAW_END` | `0.90` | loop closes |
| `RESOLVE` | `0.93` | centre resolves to the closing statement, ring pulses |

```js
drawn        = clamp01((progress - 0.02) / 0.88)   // LINEAR — no easing on the draw
dashOffset   = 1 - drawn                          // path has pathLength="1"
nodeActive[i]= drawn >= NODE_FRACTIONS[i]          // never un-sets while scrolling forward
centreIndex  = progress >= 0.93 ? 7 : lastActiveIndex
```

The draw is deliberately **linear**: it is scroll position made visible, and any easing on it
reads as lag against the wheel. All easing lives in the discrete state changes below.

Node activation in progress-space (`0.02 + fraction × 0.88`):

| Stage | 01 | 02 | 03 | 04 | 05 | 06 | 07 | close |
|---|---|---|---|---|---|---|---|---|
| `progress` | 0.020 | 0.126 | 0.252 | 0.378 | 0.503 | 0.629 | 0.755 | 0.900 |

## Durations and easings

| What | From → To | Duration | Easing |
|---|---|---|---|
| Marker fill | `transparent` + `inset 0 0 0 1.5px rgba(247,245,240,0.26)` → `--accent` + `0 0 0 0.42cqw --accent-glow` | 320ms | `ease` |
| Label colour | `rgba(247,245,240,0.34)` → `#F7F5F0` | 320ms | `ease` |
| Number colour | `rgba(247,245,240,0.30)` → `--accent` | 320ms | `ease` |
| One-liner | `opacity 0 → 1` | 320ms | `ease` |
| Centre crossfade | outgoing `1 → 0`, incoming `0 → 1`, **simultaneous** | 300ms | `ease` |
| Ring pulse | `scale(1) → 1.01 → 1` | 600ms | `cubic-bezier(0.33, 1, 0.68, 1)` |

Centre blocks are stacked in one CSS grid cell (`grid-area: 1/1`), so the crossfade cannot move
anything: **opacity only, no transform, no height change**. The ring does the moving.

Pulse fires once when `progress >= 0.93`, is removed on `animationend`, and re-arms only if the
user scrolls back below `0.85`. It never loops.

Nodes accumulate: once lit they stay lit for the rest of the section. Scrolling backwards
un-lights them again (the same threshold test, run in reverse) so the state always matches the line.

## Breakpoints

**Desktop ≥1024px** — pin 300vh, loop `min(1120px, 88vw, 78vh)` square.

**Tablet 768–1023px** — identical, pin 200vh (`--pin` override), loop shrinks via the same
`min()`; one-liners still hidden until their node activates.

**Mobile <768px** — no pinning, no circle. Vertical timeline:
- 1px ghost rule down the left edge, plus a `--accent` rule over it with
  `transform-origin: top; transform: scaleY(mobileProgress)`.
- `mobileProgress = clamp01((innerHeight × 0.75 − mwrap.top) / mwrap.height)`.
- Rows activate on an IntersectionObserver (`rootMargin: 0px 0px -35%`), not on the line:
  inactive row is `opacity: 0.34`, active is `1`, 320ms.
- After stage 07, an 86×74 SVG curve turns out of the line and points back up to stage 01,
  labelled **“and it compounds”** — an anchor to `#m-stage-1`. The loop survives without a circle.
- Each row carries number, label, one-liner **and** description (there is no centre to crossfade).

## Reduced motion

The authored HTML **is** the finished diagram: `stroke-dashoffset: 0`, every node lit, every
one-liner at `opacity: 1`, closing statement visible. JS then either *arms* it (hides what scroll
will reveal) or, under `prefers-reduced-motion: reduce`, returns immediately and binds nothing.

Consequence: no pin, no draw, no scroll-linking, no pulse, and **nothing can ever be stuck at
opacity 0** — including if JS fails to load or is disabled.

## Accessibility

- SVG paths are decorative: `aria-hidden="true"`.
- Content is a real `<ol>` of seven `<li>`, each with an `<h3>` and text, in DOM order 01→07.
  Screen readers get the sequence; absolute positioning only moves the pixels.
- Every stage's text block is `tabindex="0"` with a visible focus ring
  (`box-shadow: 0 0 0 2px rgba(90,120,255,0.9)`).
- `focus` on a stage scrolls the pin to that stage's `progress` with `window.scrollBy({behavior:'smooth'})`,
  which activates it. Native scroll only — focus is never trapped and Tab always exits the section.
- Mobile loop-back is a real `<a href="#m-stage-1">`.

## Performance

- Per frame, only `stroke-dashoffset`, `opacity`, `color`, `background-color` and `transform` change.
  No layout reads beyond one `getBoundingClientRect()` on the wrapper.
- `tick()` early-returns when progress moved less than `0.0004`, so a stationary pointer costs nothing.
- Node writes are bounded: only the nodes between the previous and current active index are touched,
  i.e. one node per threshold crossing, never seven.
- `will-change: transform` is set on the pinned child by IntersectionObserver while the section is
  in view and reset to `auto` when it leaves.
- Scroll listeners are `{ passive: true }`. `loop.js` binds `scroll`/`resize` only; the DC build
  adds a 100ms `setInterval` safety poll for embedded preview frames that suppress scroll
  events — **delete it in the port**, Framer Motion's `useScroll` covers it.

## Tweakable props (DC build)

| Prop | Editor | Default | Effect |
|---|---|---|---|
| `accentColor` | color | `#5A78FF` | sets `--accent` and derives `--accent-glow` |
| `pinLength` | range 150–500vh | `300` | sets `--pin`, i.e. how long the section holds |
| `ghostTrack` | boolean | `true` | shows/hides the undrawn loop |
