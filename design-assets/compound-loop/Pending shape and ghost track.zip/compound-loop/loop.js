/* ─────────────────────────────────────────────────────────────
   THE COMPOUND LOOP — scroll binding, framework-free.
   Extracted from Compound Loop.dc.html so it can be read on its own
   and ported to Framer Motion. Everything is driven by ONE value:
   progress 0 → 1 = how far the pinned section has been scrolled through.

   Markup contract (see SPEC.md):
     [data-el="wrap"]    the tall scroll track, height 100vh + PIN
     [data-el="sticky"]  the pinned viewport-height child
     [data-el="drawn"]   the accent path, pathLength="1"
     [data-el="track"]   the ghost path
     [data-node="0..6"]  seven stage items, each containing
                         [data-el="marker" | "num" | "label" | "line" | "text"]
     [data-centre="0..7"] eight stacked centre blocks (7 stages + closing line)
     [data-el="counter"] "0N / 07" readout

   Framer Motion port:
     const { scrollYProgress: p } = useScroll({ target: wrapRef,
       offset: ["start start", "end end"] });          // === progress()
     const drawn = useTransform(p, [0.02, 0.90], [0, 1], { clamp: true });
     const dash  = useTransform(drawn, d => 1 - d);    // strokeDashoffset
     node i active  ⇢ drawn >= NODE_FRACTIONS[i]
     centre index   ⇢ p >= 0.93 ? 7 : lastActiveIndex
   ───────────────────────────────────────────────────────────── */

// Where each node sits along the heptagon path, as a fraction of total
// path length, measured clockwise from the path start (just past the top vertex).
export const NODE_FRACTIONS = [0, 0.1207, 0.2636, 0.4064, 0.5493, 0.6922, 0.8350];

export const DRAW_START = 0.02;  // progress where the line starts drawing
export const DRAW_END   = 0.90;  // progress where the loop closes
export const RESOLVE    = 0.93;  // progress where the centre resolves to the closing line

const LIT   = { label: '#F7F5F0', num: 'var(--accent)', line: '1' };
const UNLIT = { label: 'rgba(247,245,240,0.34)', num: 'rgba(247,245,240,0.30)', line: '0' };

const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
const remap = (v, a, b) => clamp01((v - a) / (b - a));

export function initCompoundLoop(root) {
  const q = (s) => root.querySelector(s);
  const qa = (s) => Array.from(root.querySelectorAll(s));

  const el = {
    wrap: q('[data-el="wrap"]'),
    sticky: q('[data-el="sticky"]'),
    svg: q('[data-el="svg"]'),
    drawn: q('[data-el="drawn"]'),
    counter: q('[data-el="counter"]'),
    centres: qa('[data-centre]'),
    mwrap: q('[data-el="mwrap"]'),
    mline: q('[data-el="mline"]'),
  };
  const nodes = qa('[data-node]').map((li) => ({
    li,
    marker: li.querySelector('[data-el="marker"]'),
    num: li.querySelector('[data-el="num"]'),
    label: li.querySelector('[data-el="label"]'),
    line: li.querySelector('[data-el="line"]'),
    text: li.querySelector('[data-el="text"]'),
  }));
  const mnodes = qa('[data-mnode]').map((li) => ({
    li, marker: li.querySelector('[data-el="mmarker"]'),
  }));

  // The authored HTML is the FINISHED diagram: fully drawn, all nodes lit,
  // closing line visible. Reduced motion therefore binds nothing at all.
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return () => {};

  let active = -1, centre = 0, pulsed = false, lastP;

  const setNode = (n, on) => {
    const s = on ? LIT : UNLIT;
    n.marker.style.backgroundColor = on ? 'var(--accent)' : 'transparent';
    n.marker.style.boxShadow = on
      ? '0 0 0 0.42cqw var(--accent-glow)'
      : 'inset 0 0 0 1.5px rgba(247,245,240,0.26)';
    n.num.style.color = s.num;
    n.label.style.color = s.label;
    n.line.style.opacity = s.line;
  };
  const setMobileNode = (n, on) => {
    n.li.style.opacity = on ? '1' : '0.34';
    n.marker.style.backgroundColor = on ? 'var(--accent)' : 'rgba(247,245,240,0.26)';
  };

  // Hide what scroll will reveal.
  el.drawn.style.strokeDashoffset = '1';
  nodes.forEach((n) => setNode(n, false));
  el.centres.forEach((c, i) => { c.style.opacity = i === 0 ? '1' : '0'; });
  mnodes.forEach((n, i) => setMobileNode(n, i === 0));
  if (el.mline) el.mline.style.transform = 'scaleY(0)';

  /* THE single source of truth. Read from the section's own rect so it works
     whatever element scrolls (window, or a scroll container). */
  const progress = () => {
    const rect = el.wrap.getBoundingClientRect();
    const range = rect.height - window.innerHeight;
    return range <= 0 ? 0 : clamp01(-rect.top / range);
  };

  const tick = () => {
    const p = progress();
    if (lastP !== undefined && Math.abs(p - lastP) < 0.0004) return;
    lastP = p;

    const drawn = remap(p, DRAW_START, DRAW_END);   // linear with scroll

    // 1. The line draws itself.
    el.drawn.style.strokeDashoffset = String(1 - drawn);

    // 2. Nodes light and stay lit — the loop accumulates, it never hands off.
    let next = -1;
    for (let i = 0; i < NODE_FRACTIONS.length; i++) if (drawn >= NODE_FRACTIONS[i]) next = i;
    if (next !== active) {
      const from = Math.max(0, Math.min(active, next));
      const to = Math.max(active, next);
      for (let i = from; i <= to; i++) setNode(nodes[i], i <= next);
      active = next;
      el.counter.textContent =
        (active < 0 ? '00' : String(active + 1).padStart(2, '0')) + ' / 07';
    }

    // 3. The centre crossfades — opacity only, never movement.
    const nextCentre = p >= RESOLVE ? 7 : Math.max(0, active);
    if (nextCentre !== centre) {
      el.centres[centre].style.opacity = '0';
      el.centres[nextCentre].style.opacity = '1';
      centre = nextCentre;
    }

    // 4. The loop closes: one subtle pulse. Once, never looping.
    if (p >= RESOLVE && !pulsed) {
      pulsed = true;
      el.svg.style.animation = 'loopPulse 600ms cubic-bezier(0.33,1,0.68,1) 1';
      el.svg.addEventListener('animationend', () => { el.svg.style.animation = 'none'; }, { once: true });
    }
    if (p < 0.85) pulsed = false;

    // 5. Mobile: same idea, one axis. No pinning.
    if (el.mwrap && el.mwrap.offsetParent !== null) {
      const rect = el.mwrap.getBoundingClientRect();
      const mp = clamp01((window.innerHeight * 0.75 - rect.top) / rect.height);
      el.mline.style.transform = 'scaleY(' + mp.toFixed(4) + ')';
    }
  };

  // Keyboard: focusing a stage scrolls the pin to that stage, which activates it.
  // Native scroll only — Tab always continues past the section, never trapped.
  nodes.forEach((n, i) => {
    n.text.addEventListener('focus', () => {
      const rect = el.wrap.getBoundingClientRect();
      const range = rect.height - window.innerHeight;
      if (range <= 0) return;
      const target = DRAW_START + NODE_FRACTIONS[i] * (DRAW_END - DRAW_START);
      window.scrollBy({ top: (target - progress()) * range, behavior: 'smooth' });
    });
  });

  // will-change is carried only while the pinned section is on screen.
  let io;
  if ('IntersectionObserver' in window) {
    io = new IntersectionObserver((es) => {
      es.forEach((e) => { el.sticky.style.willChange = e.isIntersecting ? 'transform' : 'auto'; });
    }, { rootMargin: '15% 0px' });
    io.observe(el.wrap);
  }

  // Mobile rows activate as they enter the reading zone.
  let mio;
  if ('IntersectionObserver' in window) {
    mio = new IntersectionObserver((es) => {
      es.forEach((e) => {
        if (e.isIntersecting) setMobileNode(mnodes[+e.target.dataset.mnode], true);
      });
    }, { rootMargin: '0px 0px -35%' });
    mnodes.forEach((n) => mio.observe(n.li));
  }

  window.addEventListener('scroll', tick, { passive: true });
  window.addEventListener('resize', tick, { passive: true });
  tick();

  return () => {
    window.removeEventListener('scroll', tick);
    window.removeEventListener('resize', tick);
    if (io) io.disconnect();
    if (mio) mio.disconnect();
  };
}
