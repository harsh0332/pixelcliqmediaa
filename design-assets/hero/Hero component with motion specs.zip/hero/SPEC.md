# Hero — motion spec

Live demo: `hero/Hero.dc.html` (self-contained: markup + all styles + vanilla JS, no libraries).
Placeholders: `hero/frames/*.svg` at native ratios (9:16 ×2, 4:5, 1:1).
Responsive proof sheet: `hero/Hero Responsive.dc.html` (1440 / 768 / 390 side by side).

Only `opacity` and `transform` are animated. Every frame has explicit `width`/`height` in
markup and CSS, so CLS is 0.

---

## 1. Load sequence

Gate: an inline script in `<head>` sets `html[data-motion="on"]` **synchronously, before the hero
markup paints**, and only when `prefers-reduced-motion` is not `reduce`. All load animations are
scoped to that attribute, so with JS off or reduced motion on there is no animation and no hidden
state to recover from. Nothing is gated behind a global delay — the bone canvas, the eyebrow
hairline and the accent tick are on screen in the first frame; the container's own fade starts at
`opacity: 0.35`, never `0`, so the first painted frame always has content in it.

Easing tokens:
- `EASE_OUT_EXPO = cubic-bezier(0.22, 1, 0.36, 1)` → Framer Motion: `ease: [0.22, 1, 0.36, 1]`
- `LINEAR = linear`

| # | Element | Trigger | Delay | Duration | Easing | Property | From → To |
|---|---------|---------|-------|----------|--------|----------|-----------|
| 1 | Hero container `[data-hero]` | mount | 0 ms | 400 ms | linear | opacity | 0.35 → 1 |
| 2 | Eyebrow `[data-r=eyebrow]` | mount | 150 ms | 600 ms | EASE_OUT_EXPO | opacity + translateY | 0, +16px → 1, 0 |
| 3 | H1 line 1 “Where” | mount | 250 ms | 800 ms | EASE_OUT_EXPO | translateY (masked) | 110% → 0 |
| 4 | H1 line 2 “D2C Brands” | mount | 330 ms | 800 ms | EASE_OUT_EXPO | translateY (masked) | 110% → 0 |
| 5 | H1 line 3 “Compound.” | mount | 410 ms | 800 ms | EASE_OUT_EXPO | translateY (masked) | 110% → 0 |
| 6 | Frame A (9:16, 270×480) | mount | 550 ms | 700 ms | EASE_OUT_EXPO | opacity + translateY + scale | 0, +20px, 0.98 → 1, 0, 1 |
| 7 | Frame C (4:5, 320×400) | mount | 640 ms | 700 ms | EASE_OUT_EXPO | same as #6 | same |
| 8 | Frame D (1:1, 240×240) | mount | 730 ms | 700 ms | EASE_OUT_EXPO | same as #6 | same |
| 9 | Frame B (9:16, 216×384) | mount | 820 ms | 700 ms | EASE_OUT_EXPO | same as #6 | same |
| 10 | Accent connector rule | mount | 910 ms | 500 ms | linear | opacity | 0 → 0.9 |
| 11 | Support paragraph | mount | 600 ms | 600 ms | EASE_OUT_EXPO | opacity + translateY | 0, +16px → 1, 0 |
| 12 | CTA row | mount | 750 ms | 600 ms | EASE_OUT_EXPO | opacity + translateY | 0, +16px → 1, 0 |
| 13 | Capability strip | mount | 950 ms | 600 ms | EASE_OUT_EXPO | opacity + translateY | 0, +16px → 1, 0 |
| 14 | Vertical meta rail | mount | 950 ms | 700 ms | linear | opacity | 0 → 1 |

H1 line stagger = **80 ms**; media-frame stagger = **90 ms**. Sequence completes at 1550 ms
(last frame ends 1520 ms, strip ends 1550 ms).

Masking: each line lives in its own `overflow: hidden` block wrapper; the animated element is the
inner `<span>`. Wrappers carry `padding-bottom` (0.02–0.06em) so descenders and the italic serif
tail are not clipped at rest.

Accessibility: one real `<h1>` carrying `aria-label="Where D2C Brands Compound."`, so the split
spans never change the accessible name.

Framer Motion equivalent:

```jsx
const line = {
  hidden: { y: '110%' },
  show: (i) => ({ y: 0, transition: { delay: 0.25 + i * 0.08, duration: 0.8, ease: [0.22,1,0.36,1] } })
};
const frame = {
  hidden: { opacity: 0, y: 20, scale: 0.98 },
  show: (i) => ({ opacity: 1, y: 0, scale: 1, transition: { delay: 0.55 + i * 0.09, duration: 0.7, ease: [0.22,1,0.36,1] } })
};
```

## 2. Scroll parallax

- Trigger: window `scroll` (passive) → single `requestAnimationFrame` loop.
- Per frame: `y = clamp((1 − rate) × scrollY, −60px, +60px)`, `translate3d` only.
- Rates — A `0.9`, D `1.0`, B `1.05`, C `1.15`. A drifts *with* the page (slower), D is pinned to
  it, B and C lead it. The cluster breathes instead of sliding as a block.
- Max displacement **60 px** (hard clamp).
- Disabled entirely when `window.innerWidth < 768` (offsets forced to 0 on scroll and resize).
- Written on a dedicated parallax layer per frame; the rotation (≤2°) lives on an inner element so
  transforms never fight.

## 3. Pointer (desktop only, `@media (hover: hover)` + ≥768px)

- Cluster parallax: cursor normalised to −1…1; per-frame amplitude = `depth/10 × 10px`
  (A 2.5px, D 4px, B 7px, C 10px), Y amplitude ×0.6. Max displacement **10 px**.
- Damping: `current += (target − current) × 0.08` per frame (heavy). Framer Motion:
  `useSpring(target, { stiffness: 60, damping: 24, mass: 1 })`.
- `mouseleave` on the window returns all targets to 0.
- Primary CTA magnetism: pull = `clamp(Δx × 0.18, ±8px)` / `clamp(Δy × 0.28, ±8px)` while the
  cursor is within the button box + 90px (x) / 70px (y). Return damping `0.16` — spring-like, no
  overshoot. Max **8 px**.
- Ghost CTA underline: 1px rule, `transform: scaleX(0 → 1)`, `transform-origin: 0 50%`,
  **300 ms** `EASE_OUT_EXPO`, on `:hover` and `:focus-visible`.
- The rAF loop parks itself when nothing is moving (no idle frames).

## 4. Reduced motion (`prefers-reduced-motion: reduce`)

- The `data-motion` gate is never set → no load animation runs; every element paints in its final
  state at full opacity and zero translation.
- `animation`/`transition` are additionally hard-disabled inside the hero.
- No scroll, pointer or magnetism listeners are attached at all (early return in JS).
- The ghost CTA underline is drawn permanently (`scaleX(1)`).

## 5. Responsive

| Width | Composition |
|-------|-------------|
| ≥1240 | Full asymmetric grid. Headline block cols 1–6 on the baseline; 728×620 cluster anchored bottom-right at `right: 92px`, clear of the meta rail; meta rail on the right edge. |
| 1240–1040 | Cluster scales to 0.84 from its bottom-right corner. Grid unchanged. |
| 1040–820 | Cluster 0.56, dropped to `bottom: 24px`; support text tightened to 32ch. |
| 820–680 (768) | Cluster 0.46 and re-anchored **top-right** (`transform-origin: 100% 0; top: 96px`) so it clears the text band entirely; headline block widens to cols 1–10; support 30ch. |
| ≤680 (390) | Cluster leaves absolute positioning and becomes a **2-up grid below the CTAs** showing the 4:5 and the 1:1 only; the two 9:16 frames and the accent rule are hidden. The cluster resets to `grid-column: 1 / -1`; its inner parallax and rotation layers go 100% wide with `aspect-ratio` (4/5, 1/1) so the ratios survive. Meta rail unrotates into a horizontal caption row. Padding 72/20/40. |

**Why 2-up (4:5 + 1:1), not a row of the two 9:16s:** at 390px a 9:16 frame is ~300px tall and a
row of two would push the capability strip and the meta rail far below the fold — the cluster would
become the page instead of supporting the headline. The 4:5 and 1:1 sit within ~205px total height,
share a near-square rhythm so the row reads as one calm band, and keep the composition legible as
*media* without competing with the H1. Scroll parallax is off at that width, so the frames also
have no reason to be tall.

No horizontal overflow at 320px: `overflow-x: hidden` on `body`, `overflow: hidden` on the hero
(the rotated/overlapping cluster is clipped rather than scrolled), fluid `%` frames on mobile.

## 6. Deviations from brief (deliberate)

1. Container fade starts at `opacity: 0.35` rather than `0` — the brief's own “nothing invisible at
   first paint” rule outranks a literal 0→1 container fade.
2. Total sequence lands at ~1.55s rather than 1.4s, because the accent connector and the capability
   strip are the last things in and both were spec'd at ≥0.95s with 500–600ms durations.
3. A 70vh empty runway sits below the hero purely so the scroll parallax is demonstrable. It is
   `aria-hidden` and is not part of the hero.
